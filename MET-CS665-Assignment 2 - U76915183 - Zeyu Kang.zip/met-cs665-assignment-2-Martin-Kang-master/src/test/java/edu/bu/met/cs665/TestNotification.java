/**
 * Name: Zeyu Kang
 * Date: 10/05/2020
 * Course: CS-665
 * Assignment 2
 * Description: This is the JUnit Teat Class
 */

package edu.bu.met.cs665;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import org.junit.Test;
import edu.bu.met.cs665.notificationSystem.Shop;
import edu.bu.met.cs665.notificationSystem.DeliveryRequest;
import edu.bu.met.cs665.notificationSystem.VanDriver;
import edu.bu.met.cs665.notificationSystem.TaxiDriver;


public class TestNotification{

    public TestNotification(){}

    @Test
    public void testGetOrderID() {
        DeliveryRequest dq = new DeliveryRequest(2);
        assertEquals(2, dq.getOrderID());
    }

    @Test
    public void testMain() {
        String[] args = {"one", "two", "three"};
        Main.main(args);
    }

}
