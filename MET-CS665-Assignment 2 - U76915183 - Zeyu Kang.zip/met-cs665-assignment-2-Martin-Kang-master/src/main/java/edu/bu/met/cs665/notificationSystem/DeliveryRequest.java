/**
 * Name: Zeyu Kang
 * Date: 10/05/2020
 * Course: CS-665
 * Assignment 2
 * Description: This is the the class DeliveryRequest with the functionalities to
 * store the info of all the drivers to an ArrayList object, send the delivery request to
 * all the drivers and get the number # of current order
 */

package edu.bu.met.cs665.notificationSystem;

import java.util.*;

public class DeliveryRequest{

    private int order;

    /**
     * the ArrayList to store the info of all the drivers
     */
    private List<Driver> observers = new ArrayList<>();

    /**
     * the constructor with one argument -- an orderID object
     */
    public DeliveryRequest(int orderID){
        this.order = orderID;
    }

    /**
     * the method to add drivers to the ArrayList
     */
    public void attach(Driver driver){
        observers.add(driver);
    }

    /**
     * the method to add drivers to push the delivery
     * request to all the drivers
     */
    public void createRequest() {
        for (Driver driver : observers) {
            driver.getUpdate();
        }
    }

    /**
     * the method to get the number # of current order
     */
    public int getOrderID() {
        return order;
    }

}
