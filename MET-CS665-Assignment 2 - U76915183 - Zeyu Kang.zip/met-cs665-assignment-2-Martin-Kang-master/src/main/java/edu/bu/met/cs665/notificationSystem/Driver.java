/**
 * Name: Zeyu Kang
 * Date: 10/05/2020
 * Course: CS-665
 * Assignment 2
 * Description: This is the the abstract class Driver
 */

package edu.bu.met.cs665.notificationSystem;


public abstract class Driver {

    /**
     * two member fields represent driver's name and the object of class 'DeliveryRequest'
     */
    protected String name;
    protected DeliveryRequest request;

    /**
     * abstract method
     */
    public abstract void getUpdate();

}


