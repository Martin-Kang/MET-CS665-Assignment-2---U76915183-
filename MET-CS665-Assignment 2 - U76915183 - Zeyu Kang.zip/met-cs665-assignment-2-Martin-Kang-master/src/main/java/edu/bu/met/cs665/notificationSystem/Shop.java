/**
 * Name: Zeyu Kang
 * Date: 10/05/2020
 * Course: CS-665
 * Assignment 2
 * Description: This is the the class Shop with the functionality to set up orders
 */

package edu.bu.met.cs665.notificationSystem;

public class Shop{


    private int orderID;


    /**
     * the method to set up orders
     * it mainly has two steps: Displaying which order has been created
     * then pushing the delivery request of this order to all the drivers
     * which evoke the method 'createRequest()' in class 'DeliveryRequest'
     */
    public void setOrderID(int orderID, DeliveryRequest dq) {
        this.orderID = orderID;
        System.out.println("Order #" + orderID + " has been created!");
        dq.createRequest();
    }
}


