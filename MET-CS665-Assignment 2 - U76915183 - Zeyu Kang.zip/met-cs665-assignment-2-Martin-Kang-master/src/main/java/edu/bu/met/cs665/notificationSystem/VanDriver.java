/**
 * Name: Zeyu Kang
 * Date: 10/05/2020
 * Course: CS-665
 * Assignment 2
 * Description: This is the concrete class VanDriver that extends the abstract class 'Driver'
 */

package edu.bu.met.cs665.notificationSystem;

public class VanDriver extends Driver{

    public VanDriver(DeliveryRequest dq, String name){
        this.request = dq;
        /**
         * adding current van driver to the driver ArrayList
         */
        this.request.attach(this);
        this.name = name;
    }

    /**
     * Overriding getUpdate() method from abstract class 'Driver' which displays the result that which driver
     * received which order request
     */
    public void getUpdate(){
        System.out.println( "Request of order #"+ request.getOrderID() + " has been received by van driver " +
                name + "!");
    }
}





