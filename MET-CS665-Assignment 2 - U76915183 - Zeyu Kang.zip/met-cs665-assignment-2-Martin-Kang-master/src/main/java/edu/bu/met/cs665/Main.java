/**
 * Name: Zeyu Kang
 * Date: 10/05/2020
 * Course: CS-665
 * Assignment 2
 * Description: This is the Main Class
 */

package edu.bu.met.cs665;

import org.apache.log4j.Logger;
import edu.bu.met.cs665.notificationSystem.Shop;
import edu.bu.met.cs665.notificationSystem.DeliveryRequest;
import edu.bu.met.cs665.notificationSystem.VanDriver;
import edu.bu.met.cs665.notificationSystem.TaxiDriver;


public class Main {

    private static Logger logger = Logger.getLogger(Main.class);


    public static void main(String[] args) {

        Main m = new Main();


//    logger.trace("Trace Message!");
//    logger.debug("Debug Message!");
//    logger.info("Info Message!");
//    logger.warn("Warn Message!");
//    logger.error("Error Message!");
//    logger.fatal("Fatal Message!");

        /**
         * For testing purpose,
         * I created a Shop object s,
         * a DeliveryRequest object dq,
         * 6 driver objects -- 3 van drivers and 3 taxi drivers
         * Then evoke the method 'setOrderID()' from the class 'Shop'
         */

        Shop s = new Shop();

        DeliveryRequest dq = new DeliveryRequest(1);


        VanDriver vd1 = new VanDriver(dq, "Jack");
        VanDriver vd2 = new VanDriver(dq, "Max");
        VanDriver vd3 = new VanDriver(dq, "Jason");
        TaxiDriver td1 = new TaxiDriver(dq, "Mart");
        TaxiDriver td2 = new TaxiDriver(dq, "Will");
        TaxiDriver td3 = new TaxiDriver(dq, "Michael");


        s.setOrderID(1, dq);

    }

}
