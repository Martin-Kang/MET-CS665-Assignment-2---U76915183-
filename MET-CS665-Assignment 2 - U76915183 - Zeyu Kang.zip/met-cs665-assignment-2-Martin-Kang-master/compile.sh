#!/bin/bash

mvn clean compile
